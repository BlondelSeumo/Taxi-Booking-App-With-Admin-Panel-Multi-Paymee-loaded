package com.seentechs.newtaxidriver.home.datamodel

import android.location.Location


data class StepsClass(val location: Location , val time: String )

