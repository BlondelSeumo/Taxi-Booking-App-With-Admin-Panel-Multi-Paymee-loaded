package com.seentechs.newtaxidriver.home.datamodel

import com.google.android.gms.maps.model.LatLng

class LatLngModel {

/*<<<<<<< HEAD
    var latLngList: List<LatLng>
=======*/
    var latLngList: List<LatLng> = ArrayList<LatLng>()


    var hour: Int = 0

    var min: Int = 0
}
