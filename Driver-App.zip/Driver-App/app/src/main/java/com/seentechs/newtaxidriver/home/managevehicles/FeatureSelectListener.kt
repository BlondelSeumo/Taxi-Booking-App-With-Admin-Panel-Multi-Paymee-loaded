package com.seentechs.newtaxidriver.home.managevehicles

interface FeatureSelectListener {
    fun onFeatureChoosed(id:Int,isSelected:Boolean)
}