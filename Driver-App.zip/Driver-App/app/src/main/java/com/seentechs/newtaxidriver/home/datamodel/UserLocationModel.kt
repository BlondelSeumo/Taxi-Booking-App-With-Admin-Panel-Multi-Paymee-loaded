package com.seentechs.newtaxidriver.home.datamodel

class UserLocationModel (val lat:Double,val lng:Double,val lastTime:String){

}