package com.seentechs.newtaxidriver.home.datamodel

class Year {
    lateinit var id: String
}
