package com.seentechs.newtaxiuser.taxiapp.interfaces

/**
 * Created by Suleiman on 16/11/16.
 */

interface PaginationAdapterCallback {

    fun retryPageLoad()
}
