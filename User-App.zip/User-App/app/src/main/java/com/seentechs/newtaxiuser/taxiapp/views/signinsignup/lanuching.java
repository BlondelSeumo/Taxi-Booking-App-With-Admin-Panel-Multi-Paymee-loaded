package com.seentechs.newtaxiuser.taxiapp.views.signinsignup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.seentechs.newtaxiuser.R;

public class lanuching extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_acitvity_signin_signup);
    }
}