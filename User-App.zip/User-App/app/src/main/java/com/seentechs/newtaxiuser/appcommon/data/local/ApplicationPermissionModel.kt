package com.seentechs.newtaxiuser.appcommon.data.local

data class ApplicationPermissionModel(
    val imageId: Int,
    val title: String,
    val description: String
)
