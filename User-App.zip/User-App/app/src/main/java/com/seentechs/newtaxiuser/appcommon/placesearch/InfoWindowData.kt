package com.seentechs.newtaxiuser.appcommon.placesearch

class InfoWindowData {
    var image: String = ""
    var hotel: String= ""
    var food: String= ""
    var transport: String= ""
}
