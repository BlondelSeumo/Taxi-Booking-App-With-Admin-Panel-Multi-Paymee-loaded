package com.seentechs.newtaxiuser.taxiapp.database

interface IFirebaseReqListener {
    fun RequestListener(Tripid: String)
}
