package com.seentechs.newtaxiuser.taxiapp.datamodels

import android.location.Location


data class StepsClass(val location: Location , val time: String )

