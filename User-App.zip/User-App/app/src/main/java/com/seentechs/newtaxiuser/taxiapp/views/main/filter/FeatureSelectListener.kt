package com.seentechs.newtaxiuser.taxiapp.views.main.filter

interface FeatureSelectListener {
    fun onFeatureChoosed(id:Int,isSelected:Boolean)
}